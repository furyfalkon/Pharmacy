package main;

import gamelogic.PC;
import gameObject.items.Item;

import javax.swing.*;
import java.awt.*;

public class ApothekeSystem {

    static PC pc = new PC(); // Verbindung zu deinem PC-System

    static JFrame frame;
    static CardLayout cardLayout;
    static JPanel mainPanel;

    static double geld = 1000;

    public static void main(String[] args) {

        frame = new JFrame("Apotheke Computer");
        frame.setSize(800,600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(computerSeite(), "Computer");
        mainPanel.add(desktopSeite(), "Desktop");
        mainPanel.add(importSeite(), "Import");
        mainPanel.add(exportSeite(), "Export");

        frame.add(mainPanel);
        frame.setVisible(true);
    }

    // COMPUTER (Startbild)
    static JPanel computerSeite() {

        JPanel panel = new JPanel(null);

        JLabel bg = new JLabel(new ImageIcon("computer.png"));
        bg.setBounds(0,0,800,600);

        JButton click = new JButton();
        click.setBounds(300,200,200,150);
        makeInvisible(click);

        click.addActionListener(e -> {
            cardLayout.show(mainPanel, "Desktop");
        });

        panel.add(click);
        panel.add(bg);

        return panel;
    }

    // DESKTOP
    static JPanel desktopSeite() {

        JPanel panel = new JPanel(null);

        JLabel bg = new JLabel(new ImageIcon("desktop.png"));
        bg.setBounds(0,0,800,600);

        JButton importBtn = new JButton();
        importBtn.setBounds(200,250,120,120);
        makeInvisible(importBtn);

        importBtn.addActionListener(e -> {
            cardLayout.show(mainPanel, "Import");
        });

        JButton exportBtn = new JButton();
        exportBtn.setBounds(450,250,120,120);
        makeInvisible(exportBtn);

        exportBtn.addActionListener(e -> {
            cardLayout.show(mainPanel, "Export");
        });

        panel.add(importBtn);
        panel.add(exportBtn);
        panel.add(bg);

        return panel;
    }

    // IMPORT
    static JPanel importSeite() {

        JPanel panel = new JPanel(null);

        JLabel bg = new JLabel(new ImageIcon("import.png"));
        bg.setBounds(0,0,800,600);

        JTextField menge = new JTextField();
        menge.setBounds(300,200,100,30);

        JTextField preis = new JTextField();
        preis.setBounds(300,250,100,30);

        JButton kaufen = new JButton();
        kaufen.setBounds(300,300,150,50);
        makeInvisible(kaufen);

        kaufen.addActionListener(e -> {
            try {
                int m = Integer.parseInt(menge.getText());
                double p = Double.parseDouble(preis.getText());

                geld -= (m * p);

                // ITEM IN DEIN PC SYSTEM SPEICHERN
                Item item = new Item(); // ggf. anpassen!
                pc.addItem(item);

                JOptionPane.showMessageDialog(frame,"Import erfolgreich! Geld: " + geld);

            } catch(Exception ex){
                JOptionPane.showMessageDialog(frame,"Fehler bei Eingabe!");
            }
        });

        JButton zurück = new JButton();
        zurück.setBounds(50,500,100,50);
        makeInvisible(zurück);

        zurück.addActionListener(e -> {
            cardLayout.show(mainPanel, "Desktop");
        });

        panel.add(menge);
        panel.add(preis);
        panel.add(kaufen);
        panel.add(zurück);
        panel.add(bg);

        return panel;
    }

    // EXPORT
    static JPanel exportSeite() {

        JPanel panel = new JPanel(null);

        JLabel bg = new JLabel(new ImageIcon("export.png"));
        bg.setBounds(0,0,800,600);

        JTextField menge = new JTextField();
        menge.setBounds(300,200,100,30);

        JTextField preis = new JTextField();
        preis.setBounds(300,250,100,30);

        JButton verkaufen = new JButton();
        verkaufen.setBounds(300,300,150,50);
        makeInvisible(verkaufen);

        verkaufen.addActionListener(e -> {
            try {
                int m = Integer.parseInt(menge.getText());
                double p = Double.parseDouble(preis.getText());

                geld += (m * p);

                // ITEM AUS DEM PC HOLEN
                Item item = pc.getItem(0);

                JOptionPane.showMessageDialog(frame,"Export erfolgreich! Geld: " + geld);

            } catch(Exception ex){
                JOptionPane.showMessageDialog(frame,"Fehler!");
            }
        });

        JButton zurück = new JButton();
        zurück.setBounds(50,500,100,50);
        makeInvisible(zurück);

        zurück.addActionListener(e -> {
            cardLayout.show(mainPanel, "Desktop");
        });

        panel.add(menge);
        panel.add(preis);
        panel.add(verkaufen);
        panel.add(zurück);
        panel.add(bg);

        return panel;
    }

    // UNSICHTBARER BUTTON
    static void makeInvisible(JButton btn){
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
    }


    







}